﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class User
    {

        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public User(string username, string password)
        {
            UserName = username;
            Password = password;
        }


        public static bool Login(string username, string password, out User user)
        {
            // fali


            user = null;
            return false;
        }

        public void Logout() 
        {

        }

        public void ResetPassword(string newPassword) 
        {
            Password = newPassword;
        }

    }
}
