﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class Project
    {
        public string ProjectName { get; set; }
        public DateTime Deadline { get; set; }
        public TaskList Tasks { get; set; }

        public Project()
        {

        }


    }
}
