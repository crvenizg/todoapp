﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class TaskList
    {
        public List<TaskItem> Tasks { get; set; }

        public TaskList() 
        {
            Tasks = new List<TaskItem>();
        }

        public void AddTaskItem(TaskItem item)
        {
            Tasks.Add(item);
        }

        public void RemoveTaskItem(TaskItem item)
        {
            Tasks.Remove(item);
        }

        public void Clear()
        {
            Tasks.Clear();
        }

        public bool Contains(TaskItem item)
        {
            return Tasks.Contains(item);
        }

        public TaskItem GetTaskItem(int index)
        {
            return Tasks[index];
        }

        public List<TaskItem> GetFinishedTasks()
        {
            return Tasks.Where(item => item.Status == TaskStatus.Completed).ToList();
        }

        public List<TaskItem> GetOpenTasks()
        {
            return Tasks.Where(item => item.Status == TaskStatus.Open).ToList();
        }

        public List<TaskItem> GetOverdueTasks()
        {
            return Tasks.Where(item => item.Status == TaskStatus.Overdue).ToList();
        }
    }
}
