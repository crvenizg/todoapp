﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class TaskItem
    {
        public string TaskSummary { get; set; }
        public string Description { get; set; }
        public DateTime DueTime { get; set; }
        public TaskStatus Status { get; set; }

        public TaskItem(string taskSummary, string description)
        {
            TaskSummary = taskSummary;
            Description = description;
            DueTime = new DateTime();
            Status = TaskStatus.Open;
        }

        public TaskItem(string taskSummary, string description, TaskStatus taskStatus)
        {
            TaskSummary = taskSummary;
            Description = description;
            DueTime = new DateTime();
            Status = taskStatus;
        }

        public TaskItem(string taskSummary, string description, DateTime dateTime)
        {
            TaskSummary = taskSummary;
            Description = description;
            DueTime = dateTime;
            Status = TaskStatus.Open;
        }

        public TaskItem(string taskSummary, string description, DateTime dateTime, TaskStatus taskStatus) 
        {
            TaskSummary = taskSummary;
            Description = description;
            DueTime = dateTime;
            Status = taskStatus;
        }

        public bool IsDueSoon()
        {
            if ((DueTime - DateTime.Now).Hours <= 48)
            {
                return true;
            }
            return false;
        }

        public void MarskAsDone()
        {
            Status = TaskStatus.Completed;
        }

        public void CheckAndMarkOverude()
        {
            if (Status == TaskStatus.Open && (DueTime != DateTime.MinValue) && (DueTime - DateTime.Now).TotalSeconds <= 0)
            {
                Status = TaskStatus.Overdue;
            }
        }

        public override string ToString()
        {
            if (DueTime != DateTime.MinValue)
            {
                return "Status: " + Status + "\n\nDeadline: " + DueTime.ToShortDateString().ToString() + "\n\nDescription: " + Description;
            }
            else
            {
                return "Status: " + Status + "\n\nDescription: " + Description;
            }
        }
    }
}
