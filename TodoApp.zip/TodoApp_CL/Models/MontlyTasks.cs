﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class MontlyTasks
    {
        public TaskList Tasks { get; set; }

        //repetable
        public MontlyTasks()
        {

        }
    }
}
