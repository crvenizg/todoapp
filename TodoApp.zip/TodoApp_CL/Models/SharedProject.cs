﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TodoApp_CL.Models
{
    public class SharedProject
    {
        public int SharedProjectId { get; set; }
        public int OwnerUserId { get; set; }
        public User Owner { get; set; }
        public int SharedWithUserId { get; set; }
        public User SharedWith { get; set; }
        public TaskList Tasks { get; set; }

        public SharedProject()
        {

        }


    }
}
