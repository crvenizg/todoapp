﻿namespace TodoApp_CL
{

    public enum TaskStatus
    {
        Completed,
        Open,
        Overdue
    }


    public class HelperClass
    {
        // metode okolo rasporediti

        public static TaskStatus GetStatus(String item)
        {
            if (item.ToLower() == "completed")
            {
                return TaskStatus.Completed;
            }
            else if (item.ToLower() == "open")
            {
                return TaskStatus.Open;
            }
            else
            {
                return TaskStatus.Overdue;
            }
        }
    }
}