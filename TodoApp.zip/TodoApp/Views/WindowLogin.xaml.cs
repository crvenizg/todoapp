﻿using System;
using System.Windows;
using TodoApp.Views;
using TodoApp_CL;
using TodoApp_CL.Models;

namespace TodoApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string settingsFile = "postavke.ini";
        private string jezikSustava = String.Empty;
        private bool hideCompleted = false;
        private int numOfItemsPerList = 0;

        public MainWindow()
        {
            InitializeComponent();

            ReadSettings();
            setUILanguage(jezikSustava);
        }

        private void ReadSettings()
        {
            IniFile ini = new IniFile(settingsFile);
            jezikSustava = ini.Read("Settings", "Language").Trim();
            hideCompleted = bool.Parse(ini.Read("Settings", "TaskCount").Trim());
            numOfItemsPerList = int.Parse(ini.Read("Settings", "ShowCompleted").Trim());
        }

        private void setUILanguage(string? jezikSustava)
        {
            if (jezikSustava == "eng")
            {
                lb_username.Content = "Username:";
                lb_password.Content = "Password:";
                btn_login.Content = "Login";
                btn_signup.Content = "Register";
            }
            else if (jezikSustava == "cro")
            {
                lb_username.Content = "Korisnicko ime:";
                lb_password.Content = "Sifra:";
                btn_login.Content = "Prijavi se";
                btn_signup.Content = "Registriraj se";
            }
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            // if login razlciti od null kreiraj prozor sa userom i jezikom i ostalim postavkama
            if (User.Login(txt_username.Text, txt_password.Password, out User loggedUser) == true)
            {
                WindowDashboard windowDashboard;
                //if (jezikSustava == String.Empty)
                //{
                //    windowDashboard = new WindowDashboard(loggedUser);
                //}
                //else
                //{
                //    windowDashboard = new WindowDashboard(jezikSustava, hideCompleted, numOfItemsPerList, loggedUser);
                //}
                windowDashboard = new WindowDashboard(jezikSustava, hideCompleted, numOfItemsPerList, loggedUser);
                windowDashboard.Show();
                this.Close();
            }
        }

        private void btn_signup_Click(object sender, RoutedEventArgs e)
        {
            WindowRegister windowRegister = new WindowRegister(jezikSustava);
            windowRegister.ShowDialog();
        }
    }
}
