﻿using System;
using System.Windows;

namespace TodoApp.Views
{
    /// <summary>
    /// Interaction logic for WindowRegister.xaml
    /// </summary>
    public partial class WindowRegister : Window
    {
        public WindowRegister(String jezikSustava)
        {
            InitializeComponent();

            setUILanguage(jezikSustava);
        }

        private void setUILanguage(string jezikSustava)
        {
            if (jezikSustava == "eng")
            {
                lb_ime.Content = "Name:";
                lb_lastName.Content = "Last name:";
                lb_email.Content = "Email:";
                lb_username.Content = "Username:";
                lb_password.Content = "Password:";
                btn_save.Content = "Save";
                btn_cancel.Content = "Cancel";
            }
            else if (jezikSustava == "cro")
            {
                lb_ime.Content = "Ime:";
                lb_lastName.Content = "Prezime:";
                lb_email.Content = "Email:";
                lb_username.Content = "Korisnicko ime:";
                lb_password.Content = "Sifra:";
                btn_save.Content = "Spremi";
                btn_cancel.Content = "Odustani";
            }
        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
