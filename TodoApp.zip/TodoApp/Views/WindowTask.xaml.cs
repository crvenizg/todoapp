﻿using System;
using System.Windows;
using TodoApp_CL;
using TodoApp_CL.Models;

namespace TodoApp.Views
{
    /// <summary>
    /// Interaction logic for WindowTask.xaml
    /// </summary>
    public partial class WindowTask : Window
    {

        public TaskItem taskItem { get; set; }
        public bool saveNow { get; set; }
        public bool deleteNow { get; set; }


        public WindowTask(String jezikSustava)
        {
            InitializeComponent();

            setUILanguage(jezikSustava);

            saveNow = false;
            deleteNow = false;
        }

        public WindowTask(String jezikSustava, TaskItem item)
        {
            InitializeComponent();

            setUILanguage(jezikSustava);

            saveNow = false;
            deleteNow = false;

            taskItem = item;
            txt_taskSummaryValue.Text = taskItem.TaskSummary;
            txt_descriptionValue.Text = taskItem.Description;
            cb_statusValue.SelectedValue = taskItem.Status.ToString();
            cal_dueDate.SelectedDate = taskItem.DueTime;
        }

        private void setUILanguage(string jezikSustava)
        {
            if (jezikSustava == "eng")
            {
                lb_taskSummary.Content = "Task summary:";
                lb_description.Content = "Task description:";
                lb_status.Content = "Status:";
                lb_dueDate.Content = "Due date:";
                btn_save.Content = "Save";
                btn_delete.Content = "Delete";
                btn_cancel.Content = "Cancel";
            }
            else if (jezikSustava == "cro")
            {
                lb_taskSummary.Content = "Zadatak skraceno:";
                lb_description.Content = "Detaljan opis zadatka:";
                lb_status.Content = "Status:";
                lb_dueDate.Content = "Krajnji rok:";
                btn_save.Content = "Spremi";
                btn_delete.Content = "Obrisi";
                btn_cancel.Content = "Odustani";
            }
        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            deleteNow = true;
            this.Close();
        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {
            taskItem.TaskSummary = txt_taskSummaryValue.Text;
            taskItem.Description = txt_descriptionValue.Text;
            taskItem.Status = HelperClass.GetStatus(cb_statusValue.SelectedValue.ToString());
            taskItem.DueTime = (DateTime) cal_dueDate.SelectedDate;

            saveNow = true;
            this.Close();
        }
    }
}
