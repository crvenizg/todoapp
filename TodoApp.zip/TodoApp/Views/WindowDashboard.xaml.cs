﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TodoApp_CL.Models;

namespace TodoApp.Views
{
    /// <summary>
    /// Interaction logic for WindowDashboard.xaml
    /// </summary>
    public partial class WindowDashboard : Window
    {
        private string jezikSustava;
        private bool hideCompleted;
        private int numOfItemsPerList;
        private WindowTask windowTask;
        private WindowMontlyTask windowMontlyTask;
        private WindowProject windowProject;
        private WindowSharedProject windowSharedProject;

        public WindowDashboard(String jezik, bool hide, int numberOfPerList, User user)
        {
            InitializeComponent();

            jezikSustava = jezik;
            hideCompleted = hide;
            numOfItemsPerList = numberOfPerList;

            setUILanguage(jezikSustava);

            LoadAllData();
            FillAllTables();
        }

        private void setUILanguage(string jezikSustava)
        {
            if (jezikSustava == "eng")
            {
                btn_addNewTaskItem.Content = "Add new task";
                btn_addNewMontlyTask.Content = "Add new montly task";
                btn_addNewProject.Content = "Add new project";
                btn_addNewSharedProject.Content = "Add new shared project";
                btn_prevPage.Content = "Prev page";
                btn_nextPage.Content = "Next page";
                btn_settings.Content = "Settings";
                btn_messageUsers.Content = "Message other user";
            }
            else if (jezikSustava == "cro")
            {
                btn_addNewTaskItem.Content = "Dodaj novi zadatak";
                btn_addNewMontlyTask.Content = "Dodaj novi mjesecni zadatak";
                btn_addNewProject.Content = "Dodaj novi projekt";
                btn_addNewSharedProject.Content = "Dodaj novi zajednicki projekt";
                btn_prevPage.Content = "Prijasnja stranica";
                btn_nextPage.Content = "Sljedeca stranica";
                btn_settings.Content = "Postavke";
                btn_messageUsers.Content = "Salji poruke drugom korisniku";
            }
        }

        private void LoadAllData()
        {
            throw new NotImplementedException();
        }

        private void FillAllTables()
        {
            throw new NotImplementedException();
        }

        private void dg_taskItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is DataGridRow row)
            {
                TaskItem item = row.DataContext as TaskItem;
                tb_display.Text = item.ToString();
            }
        }

        

        private void btn_addNewTaskItem_Click(object sender, RoutedEventArgs e)
        {
            windowTask = new WindowTask(jezikSustava);
            windowTask.ShowDialog();

            if (windowTask.saveNow == true)
            {
                // napravi save u 
            }
        }

        private void taskItem_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is DataGridRow row)
            {
                TaskItem item = row.DataContext as TaskItem;
                windowTask = new WindowTask(jezikSustava, item);
                windowTask.ShowDialog();

                if (windowTask.saveNow == true)
                {
                    // napravi save u 
                }
                else if (windowTask.deleteNow == true)
                {
                    // fali i tu
                }
            }
        }

        //private void btn_addNewMontlyTask_Click(object sender, RoutedEventArgs e)
        //{
        //    windowMontlyTask = new WindowMontlyTask(jezikSustava);
        //    windowMontlyTask.ShowDialog();

        //    if (windowMontlyTask.saveNow == true)
        //    {
        //        // napravi save u 
        //    }
        //}
        //private void monthlyTask_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        //{
        //    if (sender is DataGridRow row)
        //    {
        //        TaskItem item = row.DataContext as TaskItem;
        //        windowMontlyTask = new windowMontlyTask(jezikSustava, item);
        //        windowMontlyTask.ShowDialog();

        //        if (windowMontlyTask.saveNow == true)
        //        {
        //            // napravi save u 
        //        }
        //        else if (windowMontlyTask.deleteNow == true)
        //        {
        //            // fali i tu
        //        }
        //    }
        //}
        private void btn_addNewProject_Click(object sender, RoutedEventArgs e)
        {

        }
        private void project_DoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void btn_addNewSharedProject_Click(object sender, RoutedEventArgs e)
        {

        }
        private void sharedProject_DoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void btn_settings_Click(object sender, RoutedEventArgs e)
        {
            WindowSettings windowSettings = new WindowSettings(jezikSustava, hideCompleted, numOfItemsPerList);
            windowSettings.ShowDialog();

            jezikSustava = windowSettings.jezikSustava;
            hideCompleted = windowSettings.hideCompleted;
            numOfItemsPerList = windowSettings.numOfItemsPerList;

            changeAll();
        }

        private void changeAll()
        {
            setUILanguage(jezikSustava);
            // fali paged i history
        }

        
    }
}
