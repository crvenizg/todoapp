﻿using System;
using System.Windows;
using TodoApp_CL;

namespace TodoApp.Views
{
    /// <summary>
    /// Interaction logic for WindowSettings.xaml
    /// </summary>
    public partial class WindowSettings : Window
    {
        private string settingsFile = "postavke.ini";
        public string jezikSustava = String.Empty;
        public bool hideCompleted = false;
        public int numOfItemsPerList = 0;
        public bool saveFile = false;

        public WindowSettings(String jezik, bool hide, int number)
        {
            InitializeComponent();

            jezikSustava = jezik;
            hideCompleted = hide;
            numOfItemsPerList = number;

            setInitialValuesOnUI();

            setUILanguage(jezikSustava);
        }

        private void setInitialValuesOnUI()
        {
            cb_languageValue.SelectedIndex = jezikSustava == "eng" ? 0 : 1;
            chb_completedValue.IsChecked = hideCompleted ? true : false;
            txt_numberValue.Text = numOfItemsPerList.ToString();
        }

        private void setUILanguage(string jezikSustava)
        {
            if (jezikSustava == "eng")
            {
                lb_language.Content = "Language:";
                lb_completed.Content = "Show completed:";
                lb_number.Content = "Number of tasks per list:";
            }
            else if (jezikSustava == "cro")
            {
                lb_language.Content = "Jezik:";
                lb_completed.Content = "Prikazi zavrsene taskove:";
                lb_number.Content = "Broj taskova po listi:";
            }
        }

        private void btn_save_Click(object sender, RoutedEventArgs e)
        {
            jezikSustava = cb_languageValue.SelectedValue.ToString().ToLower().Substring(0, 3);
            hideCompleted = chb_completedValue.IsChecked.Value;
            numOfItemsPerList = Int32.Parse(txt_numberValue.Text);

            IniFile ini = new IniFile(settingsFile);

            ini.Write("Settings", "Language", jezikSustava);
            ini.Write("Settings", "TaskCount", jezikSustava);
            ini.Write("Settings", "ShowCompleted", jezikSustava);

            saveFile = true;
        }

        private void btn_cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
